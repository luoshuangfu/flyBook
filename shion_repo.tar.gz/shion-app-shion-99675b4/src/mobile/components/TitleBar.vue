<template>
  <status-bar />
</template>
