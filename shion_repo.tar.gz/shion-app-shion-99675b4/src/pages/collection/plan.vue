<template>
  <page-plan />
</template>
