<template>
  <page-label />
</template>
